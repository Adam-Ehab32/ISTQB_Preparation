'use client';
import Link from 'next/link';import {usePathname} from 'next/navigation';import {useTheme} from 'next-themes';import {motion} from 'framer-motion';
const NAV=[['/','Today'],['/quiz','Quiz'],['/maps','Mind-maps']];
export default function Shell({children}:{children:React.ReactNode}){
 const p=usePathname(),{resolvedTheme,setTheme}=useTheme(),dark=resolvedTheme!=='light';
 return <div className="mx-auto max-w-5xl px-5 pb-16">
  <header className="flex flex-wrap items-center justify-between gap-3 py-5">
   <span className="font-serif text-xl">ISTQB v4.0 Prep</span>
   <nav className="flex items-center gap-1">
    {NAV.map(([h,l])=><Link key={h} href={h} className="relative rounded-full px-4 py-1.5 text-sm text-mu hover:text-tx">
     {p===h&&<motion.span layoutId="nav" className="absolute inset-0 rounded-full bg-sf ring-1 ring-ln" transition={{type:'spring',bounce:.2,duration:.5}}/>}
     <span className={`relative ${p===h?'text-tx':''}`}>{l}</span></Link>)}
    <button aria-label="Switch between dark and light mode" onClick={()=>setTheme(dark?'light':'dark')} className="ml-2 grid h-9 w-9 place-items-center rounded-full ring-1 ring-ln hover:bg-sf">
     <motion.span key={String(dark)} initial={{rotate:-80,opacity:0}} animate={{rotate:0,opacity:1}} transition={{duration:.3}}>{dark?'☾':'☀'}</motion.span></button>
   </nav></header>{children}</div>}
