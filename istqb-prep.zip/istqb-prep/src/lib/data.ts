export type K='K1'|'K2'|'K3';
export const KL:Record<K,{label:string;sec:number}>={K1:{label:'Recall',sec:30},K2:{label:'Understanding',sec:60},K3:{label:'Application',sec:120}};
export const CH=['Fundamentals','Testing in the SDLC','Static Testing','Analysis & Design','Managing Tests','Test Tools'];
export const TOPICS=[
{id:'t1',ch:1,title:'Testing vs debugging',summary:'Testing finds failures; debugging locates and removes their causes. Confirmation testing checks the fix.'},
{id:'t2',ch:1,title:'Seven principles',summary:'Presence not absence of defects, no exhaustive testing, early testing, defect clustering, tests wear out, context, absence-of-defects fallacy.'},
{id:'t3',ch:1,title:'Test process',summary:'Planning, monitoring and control, analysis, design, implementation, execution, completion.'},
{id:'t4',ch:2,title:'Test levels',summary:'Component, component integration, system, system integration and acceptance testing.'},
{id:'t5',ch:2,title:'Test types',summary:'Functional, non-functional, black-box and white-box testing.'},
{id:'t6',ch:2,title:'Change-related',summary:'Confirmation testing checks a fix; regression testing checks for side effects.'},
{id:'t7',ch:3,title:'Static vs dynamic',summary:'Static testing examines work products without running code and finds defects early.'},
{id:'t8',ch:3,title:'Review process',summary:'Planning, initiation, individual review, communication and analysis, fixing and reporting.'},
{id:'t9',ch:3,title:'Review types',summary:'Informal, walkthrough, technical review, inspection (most formal).'},
{id:'t10',ch:4,title:'Black-box',summary:'Equivalence partitioning, boundary value analysis, decision tables, state transitions.'},
{id:'t11',ch:4,title:'White-box',summary:'Statement and branch coverage. 100% branch coverage implies 100% statement coverage.'},
{id:'t12',ch:4,title:'Experience-based',summary:'Error guessing, exploratory testing and checklist-based testing.'},
{id:'t13',ch:5,title:'Planning & estimation',summary:'Entry and exit criteria; ratio, extrapolation, Wideband Delphi, three-point (a+4m+b)/6.'},
{id:'t14',ch:5,title:'Risk-based testing',summary:'Risk level = likelihood x impact. Product and project risks drive priority.'},
{id:'t15',ch:5,title:'Defect management',summary:'Reports record expected vs actual results, severity, priority, status and environment.'},
{id:'t16',ch:6,title:'Tool categories',summary:'Management, static, design, execution and coverage, performance, DevOps tools.'},
{id:'t17',ch:6,title:'Automation benefits',summary:'Saves repetitive effort, adds consistency and objectivity, reduces human error.'},
{id:'t18',ch:6,title:'Automation risks',summary:'Unrealistic expectations, underestimated effort, testware maintenance, over-reliance.'}];
export const QS:{id:string;k:K;ch:number;stem:string;options:string[];correct:number;hint:string;explanation:string}[]=[
{id:'q1',k:'K1',ch:1,stem:'Which of the following is one of the seven testing principles?',options:['Testing can prove the absence of defects','Testing shows the presence, not the absence, of defects','Early testing is rarely cost effective','Defects are evenly distributed'],correct:1,hint:'Think about what testing can never guarantee.',explanation:'Principle 1: testing reduces the probability of undiscovered defects but cannot prove correctness. Defects cluster, and early testing saves cost.'},
{id:'q2',k:'K1',ch:2,stem:'Which of the following is a test level?',options:['Component testing','Boundary value testing','Smoke testing','Exploratory testing'],correct:0,hint:'Levels are about scope in the lifecycle, not technique.',explanation:'Levels: component, component integration, system, system integration, acceptance. The others are techniques or approaches.'},
{id:'q3',k:'K2',ch:2,stem:'What distinguishes confirmation testing from regression testing?',options:['Confirmation is automated, regression is manual','Confirmation checks a fix worked; regression checks for unintended side effects','Regression happens only at acceptance level','Confirmation is a non-functional test type'],correct:1,hint:'One looks at the fixed defect, the other at everything around it.',explanation:'After a fix, confirmation re-runs the failed test. Regression tests surrounding functionality for adverse effects.'},
{id:'q4',k:'K2',ch:4,stem:'Which statement about coverage is correct?',options:['100% statement coverage guarantees 100% branch coverage','100% branch coverage guarantees 100% statement coverage','They are always equal','Neither can be measured on code'],correct:1,hint:'Branches include every outcome of every decision.',explanation:'Exercising every branch outcome executes every reachable statement. The reverse fails, e.g. an if without an else.'},
{id:'q5',k:'K3',ch:4,stem:'An age field accepts 18 to 65 inclusive. Using 2-value boundary value analysis, which values do you test?',options:['17, 18, 65, 66','18, 19, 64, 65','17, 18, 19, 65, 66','0, 18, 65, 100'],correct:0,hint:'2-value BVA: each boundary plus its closest neighbor in the adjacent partition.',explanation:'Boundaries are 18 and 65; the closest invalid neighbors are 17 and 66. 3-value BVA would also add 19 and 64.'},
{id:'q6',k:'K3',ch:5,stem:'Estimates: optimistic 6, most likely 12, pessimistic 24 days. What is the three-point estimate (a+4m+b)/6?',options:['12','13','14','15'],correct:1,hint:'Weight the most likely value four times.',explanation:'(6 + 4 x 12 + 24) / 6 = 78 / 6 = 13 days.'}];
export const CHUNKS=[
{id:'c1',min:15,title:'Review 8 concept cards',note:'Due today, mostly Chapter 1 and 2',href:'/maps',cta:'Open maps'},
{id:'c2',min:15,title:'Answer 6 mixed K1 to K3 questions',note:'Timed against the K-level target',href:'/quiz',cta:'Start quiz'},
{id:'c3',min:15,title:'Read the Chapter 4 mind-map',note:'Your lowest accuracy chapter',href:'/maps',cta:'Open chapter'}];
