'use client';
import {useState} from 'react';import Link from 'next/link';import {AnimatePresence,motion} from 'framer-motion';import {CH,TOPICS} from '@/lib/data';
export default function Maps(){
 const [c,setC]=useState(1),[s,setS]=useState<string|null>(null),ts=TOPICS.filter(t=>t.ch===c);
 const pos=(j:number)=>{const a=j/ts.length*2*Math.PI-Math.PI/2;return[50+34*Math.cos(a),50+34*Math.sin(a)]};
 return <main>
  <div className="mb-4 flex flex-wrap gap-2">{CH.map((n,j)=><button key={n} onClick={()=>{setC(j+1);setS(null)}} aria-pressed={c===j+1} className={`rounded-full px-4 py-1.5 text-sm ring-1 ${c===j+1?'bg-ac text-bg ring-ac':'ring-ln hover:bg-sf'}`}>{j+1}. {n}</button>)}</div>
  <div key={c} className="relative aspect-[3/4] overflow-hidden rounded-3xl border border-ln bg-sf sm:aspect-[16/9]">
   <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">{ts.map((t,j)=>{const[x,y]=pos(j);return <motion.line key={t.id} x1="50" y1="50" x2={x} y2={y} strokeWidth="2" vectorEffect="non-scaling-stroke" className={s===t.id?'stroke-ac':'stroke-ln'} initial={{pathLength:0}} animate={{pathLength:1}} transition={{duration:.7,delay:j*.12}}/>})}</svg>
   <div className="absolute left-1/2 top-1/2 max-w-[40%] -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-tx px-4 py-3 text-center font-serif text-lg text-bg">{CH[c-1]}</div>
   {ts.map((t,j)=>{const[x,y]=pos(j);return <div key={t.id} className="absolute max-w-[38%] -translate-x-1/2 -translate-y-1/2" style={{left:`${x}%`,top:`${y}%`}}>
    <motion.button initial={{scale:0}} animate={{scale:1}} transition={{delay:.4+j*.12,type:'spring',stiffness:260,damping:18}} whileHover={{scale:1.06}} whileTap={{scale:.96}} onClick={()=>setS(t.id)} aria-pressed={s===t.id}
     className={`rounded-2xl border px-3 py-2 text-sm font-medium ${s===t.id?'border-ac bg-ac text-bg':'border-ln bg-bg hover:border-ac'}`}>{t.title}</motion.button></div>})}</div>
  <div className="mt-4 grid gap-3 sm:grid-cols-3">{ts.map(t=><motion.article layout key={t.id} onClick={()=>setS(t.id)} className={`cursor-pointer rounded-2xl border p-5 ${s===t.id?'border-ac bg-sf':'border-ln bg-sf/60'}`}>
   <h3 className="font-serif text-xl">{t.title}</h3><p className={`mt-2 text-sm text-mu ${s===t.id?'':'line-clamp-2'}`}>{t.summary}</p>
   <AnimatePresence>{s===t.id&&<motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><Link href="/quiz" className="mt-3 inline-block text-sm text-ac underline underline-offset-4">Practice this chapter</Link></motion.div>}</AnimatePresence></motion.article>)}</div></main>}
