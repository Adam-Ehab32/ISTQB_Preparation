'use client';
import {useEffect,useState} from 'react';import Link from 'next/link';import {AnimatePresence,motion} from 'framer-motion';
import Drawer from '@/components/Drawer';import {QS,KL} from '@/lib/data';
const R=22,C=2*Math.PI*R;
export default function Quiz(){
 const [i,setI]=useState(0),[sel,setSel]=useState<number|null>(null),[left,setLeft]=useState(KL[QS[0].k].sec),[hint,setHint]=useState(false),[log,setLog]=useState<{ok:boolean;t:number;k:string}[]>([]);
 const done=i>=QS.length,q=QS[Math.min(i,QS.length-1)],sec=KL[q.k].sec;
 useEffect(()=>{setSel(null);setLeft(sec)},[i,sec]);
 useEffect(()=>{if(sel!==null||done)return;const id=setInterval(()=>setLeft(l=>l-1),1000);return()=>clearInterval(id)},[sel,done,i]);
 const ans=(n:number)=>{if(sel!==null)return;setSel(n);setLog(l=>[...l,{ok:n===q.correct,t:sec-Math.max(left,0),k:q.k}])};
 useEffect(()=>{if(left<=0&&sel===null&&!done)ans(-1)},[left]); // eslint-disable-line
 if(done){const ok=log.filter(x=>x.ok).length,slow=log.filter(x=>x.k==='K1'&&x.t>KL.K1.sec*.8).length;
  return <main className="rounded-3xl border border-ln bg-sf p-8"><h1 className="font-serif text-4xl">{ok} of {log.length} correct</h1>
   <p className="mt-2 text-mu">Average {Math.round(log.reduce((s,x)=>s+x.t,0)/log.length)}s per question. {slow?`${slow} simple K1 question(s) used most of the time limit; review those chapters.`:'K1 answers were fast.'}</p>
   <button onClick={()=>{setLog([]);setI(0)}} className="mt-5 rounded-full bg-ac px-5 py-2 text-bg">Try again</button> <Link href="/" className="ml-2 rounded-full px-5 py-2 ring-1 ring-ln">Back to today</Link></main>}
 const urgent=left<=10&&sel===null,verdict=sel===null?null:sel===-1?'Time is up':sel===q.correct?'Correct':'Not quite';
 return <main className="rounded-3xl border border-ln bg-sf p-6 md:p-8">
  <div className="flex items-center justify-between gap-4">
   <div className="flex items-center gap-2"><span className="rounded-md bg-ac/15 px-2.5 py-1 text-sm font-semibold text-ac">{q.k} {KL[q.k].label}</span><span className="text-sm text-mu">Question {i+1} of {QS.length}</span></div>
   <div role="timer" aria-label={`${Math.max(left,0)} seconds left`} className="relative h-14 w-14"><svg viewBox="0 0 52 52" className="-rotate-90"><circle cx="26" cy="26" r={R} fill="none" strokeWidth="4" className="stroke-ln"/>
    <motion.circle cx="26" cy="26" r={R} fill="none" strokeWidth="4" strokeLinecap="round" strokeDasharray={C} animate={{strokeDashoffset:C*(1-Math.max(left,0)/sec)}} transition={{duration:1,ease:'linear'}} className={urgent?'stroke-bad':'stroke-ac'}/></svg>
    <span className={`absolute inset-0 grid place-items-center text-sm tabular-nums ${urgent?'text-bad':''}`}>{Math.max(left,0)}</span></div></div>
  <AnimatePresence mode="wait"><motion.div key={i} initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-24}} transition={{duration:.25}}>
   <h1 className="my-6 font-serif text-2xl leading-snug md:text-3xl">{q.stem}</h1>
   <div className="space-y-2">{q.options.map((o,n)=>{const st=sel===null?'border-ln hover:border-ac':n===q.correct?'border-ok bg-ok/10':n===sel?'border-bad bg-bad/10':'border-ln opacity-60';
    return <motion.button key={n} whileTap={{scale:.985}} disabled={sel!==null} onClick={()=>ans(n)} className={`block w-full rounded-2xl border p-4 text-left ${st}`}><span className="mr-3 text-mu">{'ABCD'[n]}</span>{o}</motion.button>})}</div></motion.div></AnimatePresence>
  <div className="mt-5 flex flex-wrap items-center gap-3"><button onClick={()=>setHint(true)} className="rounded-full px-4 py-2 text-sm ring-1 ring-ln hover:bg-bg">Get concept hint</button>
   {sel!==null&&<motion.button initial={{opacity:0}} animate={{opacity:1}} onClick={()=>setI(i+1)} className="rounded-full bg-ac px-5 py-2 text-sm text-bg">{i+1<QS.length?'Next question':'See results'}</motion.button>}</div>
  <AnimatePresence>{verdict&&<motion.div key="ex" initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}} className="overflow-hidden"><div className={`mt-5 rounded-2xl border p-4 ${sel===q.correct?'border-ok':'border-bad'}`}><div className="font-semibold">{verdict}. The answer is {'ABCD'[q.correct]}.</div><p className="mt-1 text-mu">{q.explanation}</p></div></motion.div>}</AnimatePresence>
  <Drawer open={hint} onClose={()=>setHint(false)} title="Concept hint"><p>{q.hint}</p><p className="mt-4 text-sm text-mu">Chapter {q.ch}. Target time for {q.k}: {sec} seconds.</p></Drawer></main>}
