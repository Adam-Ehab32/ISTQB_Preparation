'use client';
import {useState} from 'react';import Link from 'next/link';import {motion} from 'framer-motion';import {CHUNKS} from '@/lib/data';
export default function Dashboard(){
 const [done,setDone]=useState<string[]>([]),mins=done.length*15,tot=CHUNKS.length*15;
 const toggle=(id:string)=>setDone(d=>d.includes(id)?d.filter(x=>x!==id):[...d,id]);
 return <main className="grid gap-4 md:grid-cols-3">
  <section className="rounded-3xl border border-ln bg-sf p-6 md:col-span-2 md:row-span-2">
   <h1 className="font-serif text-3xl">Three 15-minute chunks today</h1>
   <p className="mt-1 text-mu">{mins} of {tot} minutes done</p>
   <div className="my-4 h-2 overflow-hidden rounded-full bg-ln"><motion.div className="h-full bg-ac" animate={{width:`${mins/tot*100}%`}} transition={{type:'spring',stiffness:120,damping:20}}/></div>
   <ul className="space-y-3">{CHUNKS.map(c=>{const d=done.includes(c.id);return <motion.li layout key={c.id} className="flex items-center gap-4 rounded-2xl border border-ln bg-bg p-4">
    <button role="checkbox" aria-checked={d} aria-label={`Mark "${c.title}" ${d?'not done':'done'}`} onClick={()=>toggle(c.id)} className="grid h-7 w-7 shrink-0 place-items-center rounded-full ring-1 ring-ln">
     <motion.span initial={false} animate={{scale:d?1:0}} className="grid h-7 w-7 place-items-center rounded-full bg-ok text-sm text-bg">✓</motion.span></button>
    <div className="min-w-0 flex-1"><div className={d?'text-mu line-through':''}>{c.title}</div><div className="text-sm text-mu">{c.min} min. {c.note}</div></div>
    <Link href={c.href} className="rounded-full px-4 py-1.5 text-sm ring-1 ring-ln hover:bg-sf">{c.cta}</Link></motion.li>})}</ul></section>
  <section className="rounded-3xl border border-ln bg-sf p-6"><div className="text-sm text-mu">Streak</div><div className="font-serif text-5xl">6 days</div><p className="mt-1 text-sm text-mu">Finish one chunk to keep it going.</p></section>
  <section className="rounded-3xl border border-ln bg-sf p-6"><div className="text-sm text-mu">Cards due</div><div className="font-serif text-5xl">8</div><Link href="/maps" className="mt-3 inline-block text-sm text-ac underline underline-offset-4">Review them</Link></section>
 </main>}
