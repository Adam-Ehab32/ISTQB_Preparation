# ISTQB v4.0 Prep Master (frontend)
Next.js 14 + Tailwind + Framer Motion. Obsidian dark default, smooth light toggle. Data is mocked in src/lib/data.ts (shapes mirror the Supabase schema).

    npm i && npm run dev
